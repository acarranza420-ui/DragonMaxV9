import os, json, zipfile, traceback, time, shutil
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
try:
    from urllib.request import urlopen
except Exception:
    from urllib2 import urlopen

ADDON = xbmcaddon.Addon()
BASE_URL = 'https://acarranza420-ui.github.io/DragonMaxV9/'
VERSION = '1.9.6'
BUILD_ZIP = 'DragonMax_V9_6_Build_Content-1.9.6.zip'
MANIFESTS = ['build.json','updates.json','themes.json','realms.json','legal_addons.json','addons.xml','addons.xml.md5']


def spath(p):
    return xbmcvfs.translatePath(p)

def notify(msg, level=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification('DragonMax Wizard', msg, level, 3500)

def mkdirs(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

def fetch_bytes(name):
    return urlopen(BASE_URL + name, timeout=25).read()

def fetch_text(name):
    return fetch_bytes(name).decode('utf-8','ignore')

def download(url, dest):
    notify('Downloading ' + os.path.basename(dest))
    data = urlopen(url, timeout=90).read()
    with open(dest, 'wb') as f:
        f.write(data)
    return dest, len(data)

def copytree(src, dst):
    mkdirs(dst)
    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        target_root = dst if rel == '.' else os.path.join(dst, rel)
        mkdirs(target_root)
        for d in dirs:
            mkdirs(os.path.join(target_root, d))
        for f in files:
            s = os.path.join(root, f)
            t = os.path.join(target_root, f)
            try:
                if xbmcvfs.exists(t):
                    xbmcvfs.delete(t)
                xbmcvfs.copy(s, t)
            except Exception:
                try:
                    with open(s, 'rb') as rf, open(t, 'wb') as wf:
                        wf.write(rf.read())
                except Exception:
                    pass

def backup_marker():
    backup_root = spath('special://home/DragonMax_Backups/')
    mkdirs(backup_root)
    stamp = time.strftime('%Y%m%d-%H%M%S')
    marker = os.path.join(backup_root, 'backup-' + stamp + '.txt')
    with open(marker, 'w') as f:
        f.write('DragonMax backup marker before V9.6 install.\n')
        f.write('Version: ' + VERSION + '\n')
    return marker

def find_payload_root(stage):
    if os.path.exists(os.path.join(stage,'userdata')) or os.path.exists(os.path.join(stage,'dragonmax')):
        return stage
    dirs=[os.path.join(stage,e) for e in os.listdir(stage) if os.path.isdir(os.path.join(stage,e))]
    return dirs[0] if len(dirs)==1 else stage

def install_build():
    try:
        home=spath('special://home/')
        userdata=spath('special://userdata/')
        packages=spath('special://home/addons/packages/')
        mkdirs(packages)
        manifest=json.loads(fetch_text('build.json'))
        build_zip=manifest.get('build_zip', BUILD_ZIP)
        zip_path=os.path.join(packages, build_zip)
        _,size=download(BASE_URL+build_zip, zip_path)
        if size < 1000:
            raise Exception('Downloaded payload too small. Reupload build ZIP to GitHub Pages root.')
        stage=os.path.join(home,'DragonMax_Staged_Build')
        if os.path.exists(stage):
            shutil.rmtree(stage, ignore_errors=True)
        mkdirs(stage)
        with zipfile.ZipFile(zip_path,'r') as z:
            bad=z.testzip()
            if bad: raise Exception('Bad file inside build ZIP: '+str(bad))
            z.extractall(stage)
        root=find_payload_root(stage)
        marker=backup_marker()
        applied=[]
        for folder,dest in [('userdata',userdata),('addons',os.path.join(home,'addons')),('dragonmax',os.path.join(home,'DragonMax')),('media',os.path.join(home,'media','DragonMax'))]:
            src=os.path.join(root,folder)
            if os.path.exists(src):
                copytree(src,dest); applied.append(folder)
        dm=os.path.join(home,'DragonMax'); mkdirs(dm)
        with open(os.path.join(dm,'install_status.txt'),'w') as f:
            f.write('DragonMax V9.6 applied/staged.\nApplied: '+', '.join(applied)+'\nBackup marker: '+marker+'\n')
        xbmcgui.Dialog().ok('DragonMax Installed','V9.6 payload downloaded and applied/staged.','Restart Kodi to load updated menus, widgets, and support files.')
    except Exception as e:
        xbmcgui.Dialog().ok('DragonMax Install Failed',str(e),traceback.format_exc()[-1200:])

def check_online():
    names=MANIFESTS+[f'repository.dragonmax-1.9.6.zip',f'plugin.program.dragonmaxwizard-1.9.6.zip',BUILD_ZIP]
    results=[]
    for name in names:
        try:
            raw=fetch_bytes(name); results.append(name+': OK ('+str(len(raw))+' bytes)')
        except Exception as e:
            results.append(name+': FAIL - '+str(e))
    xbmcgui.Dialog().textviewer('DragonMax Online Check','\n'.join(results))

def admin_center():
    items=['System Status','Online Manifest Check','Safe Mode Info','Recommended Legal Add-ons','Troubleshooting Guides','Back']
    i=xbmcgui.Dialog().select('DragonMax Admin Center',items)
    if i==0:
        xbmcgui.Dialog().textviewer('System Status','Storage/RAM/cache checks are staged in DragonMax health_monitor.json. Use Log Viewer for Kodi for deeper runtime logs.')
    elif i==1:
        check_online()
    elif i==2:
        xbmcgui.Dialog().ok('Safe Mode','Disables animations, particles, dynamic backgrounds, and heavy widgets. Reapply the build payload to restore safe defaults.')
    elif i==3:
        try: xbmcgui.Dialog().textviewer('Recommended Add-ons',fetch_text('legal_addons.json'))
        except Exception: xbmcgui.Dialog().ok('Add-ons','Upload legal_addons.json to GitHub Pages root.')
    elif i==4:
        xbmcgui.Dialog().textviewer('Troubleshooting','Invalid ZIP Structure: install repo ZIP, not Build_Content ZIP.\nCould Not Connect: verify addons.xml and md5.\nUpdate Failed: verify build.json and updates.json.\nUse Log Viewer for Kodi or Kodi Logfile Uploader for logs.')

def recovery_menu():
    items=['Repair Menus','Repair Widgets','Repair Themes','Repair Realm','Restore Home Screen','Restore Safe Mode','View Install Marker','Back']
    i=xbmcgui.Dialog().select('DragonMax Recovery',items)
    if i in range(0,6):
        xbmcgui.Dialog().ok('DragonMax Recovery',items[i]+' staged. Re-run Install / Apply to refresh payload files.')
    elif i==6:
        marker=os.path.join(spath('special://home/'),'DragonMax','install_status.txt')
        if os.path.exists(marker): xbmcgui.Dialog().textviewer('Install Marker',open(marker).read())
        else: xbmcgui.Dialog().ok('DragonMax Recovery','No install marker found.')

menu=['Install / Apply DragonMax V9.6 Build','Online Manifest Check','Dragon Portal Admin Center','Repair / Recovery Center','Performance / Safe Mode','Help: Do Not Install Payload ZIP Directly']
idx=xbmcgui.Dialog().select('DragonMax Wizard',menu)
if idx==0: install_build()
elif idx==1: check_online()
elif idx==2: admin_center()
elif idx==3: recovery_menu()
elif idx==4: xbmcgui.Dialog().ok('Performance Modes','Balanced is default. Maximum Speed limits widgets and disables heavy animation. Safe Mode helps troubleshoot broken skins/widgets.')
elif idx==5: xbmcgui.Dialog().textviewer('DragonMax Help','Install repository.dragonmax-1.9.6.zip first. Then install DragonMax Wizard from the repository. Run the wizard to apply DragonMax_V9_6_Build_Content. Do not install Build_Content directly; it is a payload, not a Kodi add-on.')
