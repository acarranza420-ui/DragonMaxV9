DragonMax V9.8 build payload. This ZIP is NOT a Kodi add-on. It must be downloaded and extracted by DragonMax Wizard.
