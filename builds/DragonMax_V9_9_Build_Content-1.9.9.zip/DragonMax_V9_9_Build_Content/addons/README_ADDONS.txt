Add-on payload placeholder. Legal add-ons should be installed through official repositories.
