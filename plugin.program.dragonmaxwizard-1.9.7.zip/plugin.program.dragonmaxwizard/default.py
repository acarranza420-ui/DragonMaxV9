import os, json, zipfile, traceback, time, shutil
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
try:
    from urllib.request import urlopen
except Exception:
    from urllib2 import urlopen

ADDON = xbmcaddon.Addon()
BASE_URL = 'https://acarranza420-ui.github.io/DragonMaxV9/'
VERSION = '1.9.7'
MANIFESTS = ['addons.xml','addons.xml.md5','build.json','updates.json','themes.json','realms.json','legal_addons.json']

def spath(p):
    return xbmcvfs.translatePath(p)

def notify(msg, level=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification('DragonMax Wizard', msg, level, 3500)

def mkdirs(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

def fetch_bytes(path):
    return urlopen(BASE_URL + path, timeout=30).read()

def fetch_text(path):
    return fetch_bytes(path).decode('utf-8','ignore')

def download(url, dest):
    notify('Downloading ' + os.path.basename(dest))
    data = urlopen(url, timeout=120).read()
    with open(dest, 'wb') as f:
        f.write(data)
    return len(data)

def copytree(src, dst):
    mkdirs(dst)
    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        target_root = dst if rel == '.' else os.path.join(dst, rel)
        mkdirs(target_root)
        for d in dirs:
            mkdirs(os.path.join(target_root, d))
        for fn in files:
            s=os.path.join(root,fn); t=os.path.join(target_root,fn)
            try:
                if xbmcvfs.exists(t): xbmcvfs.delete(t)
                xbmcvfs.copy(s,t)
            except Exception:
                try:
                    with open(s,'rb') as rf, open(t,'wb') as wf: wf.write(rf.read())
                except Exception: pass

def backup_marker():
    backup_root=spath('special://home/DragonMax_Backups/')
    mkdirs(backup_root)
    marker=os.path.join(backup_root,'backup-before-v%s-%s.txt'%(VERSION,time.strftime('%Y%m%d-%H%M%S')))
    with open(marker,'w') as f:
        f.write('DragonMax backup marker before install.\nVersion: '+VERSION+'\n')
    return marker

def find_payload_root(stage):
    expected=['userdata','addons','dragonmax','media']
    if any(os.path.exists(os.path.join(stage,x)) for x in expected): return stage
    dirs=[os.path.join(stage,e) for e in os.listdir(stage) if os.path.isdir(os.path.join(stage,e))]
    return dirs[0] if len(dirs)==1 else stage

def validate_payload_zip(zpath):
    with zipfile.ZipFile(zpath,'r') as z:
        bad=z.testzip()
        if bad: raise Exception('Bad file inside payload: '+str(bad))
        names=z.namelist()
        if any(n.endswith('addon.xml') and n.count('/') <= 1 for n in names):
            raise Exception('This looks like an add-on ZIP, not the DragonMax build payload.')
        if not any(n.startswith('DragonMax_V9_7_Build_Content/') or n.startswith('userdata/') or n.startswith('dragonmax/') for n in names):
            raise Exception('Payload missing DragonMax build folders.')

def install_build():
    try:
        manifest=json.loads(fetch_text('build.json'))
        build_path=manifest.get('build_path') or manifest.get('build_zip')
        if not build_path:
            raise Exception('build.json missing build_path')
        home=spath('special://home/')
        userdata=spath('special://userdata/')
        packages=spath('special://home/addons/packages/')
        mkdirs(packages)
        zpath=os.path.join(packages, os.path.basename(build_path))
        size=download(BASE_URL + build_path, zpath)
        if size < 1000:
            raise Exception('Downloaded payload too small. Check GitHub Pages path: '+build_path)
        validate_payload_zip(zpath)
        stage=os.path.join(home,'DragonMax_Staged_Build')
        if os.path.exists(stage): shutil.rmtree(stage, ignore_errors=True)
        mkdirs(stage)
        with zipfile.ZipFile(zpath,'r') as z: z.extractall(stage)
        root=find_payload_root(stage)
        marker=backup_marker()
        applied=[]
        targets=[('userdata',userdata),('addons',os.path.join(home,'addons')),('dragonmax',os.path.join(home,'DragonMax')),('media',os.path.join(home,'media','DragonMax'))]
        for folder,dest in targets:
            src=os.path.join(root,folder)
            if os.path.exists(src):
                copytree(src,dest); applied.append(folder)
        dm=os.path.join(home,'DragonMax'); mkdirs(dm)
        with open(os.path.join(dm,'install_status.txt'),'w') as f:
            f.write('DragonMax V9.7 applied.\nApplied folders: '+', '.join(applied)+'\nBackup marker: '+marker+'\n')
        xbmcgui.Dialog().ok('DragonMax Installed','DragonMax V9.7 payload applied.','Restart Kodi to load DragonMax.')
    except Exception as e:
        xbmcgui.Dialog().textviewer('DragonMax Install Failed',str(e)+'\n\n'+traceback.format_exc()[-1800:])

def online_check():
    names=MANIFESTS+['repository.dragonmax-1.9.7.zip','plugin.program.dragonmaxwizard-1.9.7.zip','builds/DragonMax_V9_7_Build_Content-1.9.7.zip']
    out=[]
    for name in names:
        try:
            raw=fetch_bytes(name)
            out.append(name+': OK ('+str(len(raw))+' bytes)')
        except Exception as e:
            out.append(name+': FAIL - '+str(e))
    xbmcgui.Dialog().textviewer('DragonMax Online Check','\n'.join(out))

def help_screen():
    xbmcgui.Dialog().textviewer('DragonMax Install Help','Install ONLY repository.dragonmax-1.9.7.zip from Kodi.\n\nThen install DragonMax Wizard from the repository and run Install / Apply Build.\n\nDo NOT install the Build_Content ZIP. It lives in /builds and is only for wizard extraction. If Kodi says Invalid Structure, you clicked a payload ZIP instead of the repo ZIP.')

def recovery():
    items=['Repair Menus','Repair Widgets','Repair Theme','Restore Safe Mode','Show Install Marker','Back']
    i=xbmcgui.Dialog().select('DragonMax Recovery',items)
    if i in [0,1,2,3]: xbmcgui.Dialog().ok('DragonMax Recovery',items[i]+' staged. Re-run Install / Apply Build to refresh files.')
    if i==4:
        marker=os.path.join(spath('special://home/'),'DragonMax','install_status.txt')
        if os.path.exists(marker): xbmcgui.Dialog().textviewer('Install Marker',open(marker).read())
        else: xbmcgui.Dialog().ok('DragonMax Recovery','No install marker found yet.')

menu=['Install / Apply DragonMax V9.7 Build','Online Manifest Check','Repair / Recovery','Help: Correct Install Flow']
idx=xbmcgui.Dialog().select('DragonMax Wizard',menu)
if idx==0: install_build()
elif idx==1: online_check()
elif idx==2: recovery()
elif idx==3: help_screen()
